import tkinter as tk
from tkinter import filedialog, messagebox
import geopandas as gpd
import pandas as pd
from shapely.geometry import LineString
from shapely.ops import unary_union
import os
import subprocess
import json
import argparse
from sqlalchemy import create_engine, text

# Constants
ICON_PATH = r"D:/2025_PROJECTS/BLGF-GM_TEST/FOR TESTING/DCS_CODES/BLGF.ico"
GM_EXE_PATH = r"C:\Program Files\GlobalMapper26.1_64bit\global_mapper.exe"
PROCESSED_OUTPUTS_JSON = "processed_outputs.json"


def open_in_global_mapper(output_path):
    if os.path.exists(GM_EXE_PATH) and os.path.exists(output_path):
        subprocess.Popen([GM_EXE_PATH, output_path], shell=True)


def get_sqlalchemy_engine():
    with open("db_conn.json", "r") as f:
        config = json.load(f)
    uri = f"postgresql+psycopg2://{config['user']}:{config['password']}@{config['host']}:{config['port']}/{config['dbname']}"
    return create_engine(uri)


def load_from_postgis(table):
    engine = get_sqlalchemy_engine()
    with engine.connect() as conn:
        result = conn.execute(text(f"""
            SELECT column_name FROM information_schema.columns
            WHERE table_name = '{table}' AND udt_name = 'geometry'
        """))
        geom_cols = [row[0] for row in result]
    if not geom_cols:
        raise ValueError(f"No geometry column found in table: {table}")
    if len(geom_cols) > 1:
        raise ValueError(f"Multiple geometry columns found: {geom_cols}")
    geom_col = geom_cols[0]

    query = f'SELECT * FROM "{table}"'
    gdf = gpd.read_postgis(sql=query, con=get_sqlalchemy_engine(), geom_col=geom_col)
    if not gdf.crs:
        gdf.set_crs("EPSG:32651", inplace=True)
    return gdf


def split_boundary_to_segments(boundary):
    segments = []
    if boundary.geom_type == 'LineString':
        coords = list(boundary.coords)
        segments.extend([LineString([coords[i], coords[i + 1]]) for i in range(len(coords) - 1)])
    elif boundary.geom_type == 'MultiLineString':
        for line in boundary.geoms:
            coords = list(line.coords)
            segments.extend([LineString([coords[i], coords[i + 1]]) for i in range(len(coords) - 1)])
    return segments


def process_frontage_single(brgy_gdf, road_gdf):
    if not brgy_gdf.crs or not road_gdf.crs:
        raise ValueError("Missing CRS on one or both datasets.")
    if brgy_gdf.crs != road_gdf.crs:
        road_gdf = road_gdf.to_crs(brgy_gdf.crs)

    road_buffer = unary_union(road_gdf.geometry).buffer(10)
    frontage_lengths = []

    geom_col = brgy_gdf.geometry.name  # Ensure correct geometry column reference

    for _, row in brgy_gdf.iterrows():
        boundary = row[geom_col].boundary
        segments = split_boundary_to_segments(boundary)
        frontage_total = sum(seg.length for seg in segments if seg.within(road_buffer))
        frontage_lengths.append(frontage_total)

    brgy_gdf["ROAD_FRONT"] = frontage_lengths
    return brgy_gdf



def save_output(gdf, name, output_dir):
    output_path = os.path.join(output_dir, f"{name}_with_frontage.shp")
    gdf.to_file(output_path)

    # Track outputs
    if os.path.exists(PROCESSED_OUTPUTS_JSON):
        with open(PROCESSED_OUTPUTS_JSON, "r") as f:
            existing = json.load(f)
    else:
        existing = {}

    existing[name] = output_path
    with open(PROCESSED_OUTPUTS_JSON, "w") as f:
        json.dump(existing, f)

    open_in_global_mapper(output_path)


def update_db_from_output(shapefile_path, target_table):
    gdf = gpd.read_file(shapefile_path)
    if not gdf.crs:
        gdf.set_crs("EPSG:32651", inplace=True)

    if 'geometry' in gdf.columns:
        gdf = gdf.rename(columns={'geometry': 'geom'})
        gdf.set_geometry('geom', inplace=True)

    gdf.to_postgis(name=target_table, con=get_sqlalchemy_engine(), if_exists='replace', index=False)
    print(f"✅ Updated PostgreSQL table: {target_table}")


def update_all_frontage_tables():
    if not os.path.exists(PROCESSED_OUTPUTS_JSON):
        print("❌ No processed_outputs.json found.")
        return

    with open(PROCESSED_OUTPUTS_JSON, "r") as f:
        data = json.load(f)

    for table, path in data.items():
        if os.path.exists(path) and path.endswith("_with_frontage.shp"):
            try:
                update_db_from_output(path, table)
            except Exception as e:
                print(f"❌ Failed to update {table}: {e}")


def run_from_postgis(road_table, brgy_tables, output_dir):
    road_gdf = load_from_postgis(road_table)
    for brgy_table in brgy_tables:
        brgy_gdf = load_from_postgis(brgy_table)
        result = process_frontage_single(brgy_gdf, road_gdf)
        save_output(result, brgy_table, output_dir)


def run_local_gui():
    root = tk.Tk()
    root.withdraw()

    road_path = filedialog.askopenfilename(title="Select Road Shapefile")
    brgy_paths = filedialog.askopenfilenames(title="Select Barangay Shapefiles")
    output_dir = filedialog.askdirectory(title="Select Output Folder")
    if not (road_path and brgy_paths and output_dir):
        return

    road_gdf = gpd.read_file(road_path)
    for path in brgy_paths:
        brgy_gdf = gpd.read_file(path)
        result = process_frontage_single(brgy_gdf, road_gdf)
        name = os.path.splitext(os.path.basename(path))[0]
        save_output(result, name, output_dir)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--from-db", action="store_true")
    parser.add_argument("--road", type=str)
    parser.add_argument("--brgy", type=str)
    parser.add_argument("--output", type=str)
    args = parser.parse_args()

    if args.from_db:
        brgy_list = args.brgy.split(",")
        run_from_postgis(args.road, brgy_list, args.output)
    else:
        run_local_gui()
