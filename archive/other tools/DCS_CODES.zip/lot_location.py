import tkinter as tk
from tkinter import filedialog, messagebox
import geopandas as gpd
import pandas as pd
import globalmapper as gm
import os
import shutil
import subprocess

# 🔥 Set your paths here
GM_EXE_PATH = r"C:\Program Files\GlobalMapper26.1_64bit\global_mapper.exe"
ICON_PATH = r"D:/2025_PROJECTS/BLGF-GM_TEST/FOR TESTING/DCS_CODES/BLGF.ico"

# Global file variables
road_shp = ""
barangay_shps = []
attrs_to_copy = ["ROAD_NAME", "ROAD_TYPE", "ROAD_ID", "LOT_LOC"]
output_files = []

def get_prj_file(shp_file):
    prj_file = shp_file.replace(".shp", ".prj")
    return prj_file if os.path.exists(prj_file) else None

def add_lot_location_field(output_shp):
    try:
        gdf = gpd.read_file(output_shp)

        if "ROAD_ID" not in gdf.columns:
            raise KeyError("ROAD_ID field not found in the shapefile.")

        def assign_lot_location(road_id):
            if pd.isna(road_id) or road_id is None or road_id == "":
                return "0"
            elif "," in str(road_id):
                return "2"
            else:
                return "1"

        gdf["LOT_LOCATION"] = gdf["ROAD_ID"].apply(assign_lot_location)
        gdf.to_file(output_shp, encoding='utf-8')

        # Ensure UTF-8 .cpg file
        cpg_file = output_shp.replace(".shp", ".cpg")
        if not os.path.exists(cpg_file):
            with open(cpg_file, 'w') as f:
                f.write('UTF-8\n')

    except KeyError as ke:
        messagebox.showerror("Error", f"Failed to add LOT_LOCATION field: {ke}")
    except Exception as e:
        messagebox.showerror("Error", f"Failed to add LOT_LOCATION field: {e}")

def load_into_global_mapper(shapefile_path):
    try:
        if not os.path.exists(GM_EXE_PATH):
            messagebox.showerror("Error", f"Global Mapper not found at:\n{GM_EXE_PATH}")
            return

        cmd = f'"{GM_EXE_PATH}" "{shapefile_path}"'
        subprocess.Popen(cmd, shell=True)
        print(f"🗺️ Sent to Global Mapper: {shapefile_path}")

    except Exception as e:
        messagebox.showerror("Error", f"Failed to load into Global Mapper:\n{e}")

def process_lot_location(road_shp, barangay_shps, output_dir):
    try:
        road_prj = get_prj_file(road_shp)
        if not road_prj:
            messagebox.showerror("Error", "No .prj file found for the Road shapefile.")
            return

        # Build Global Mapper script
        script = f"""GLOBAL_MAPPER_SCRIPT VERSION=1.00
IMPORT FILENAME="{road_shp}"
"""

        output_files.clear()
        attrs_string = " ".join([f'ATTR_TO_COPY="{attr}"' for attr in attrs_to_copy])

        for barangay_shp in barangay_shps:
            barangay_shp = barangay_shp.replace("\\", "/")
            barangay_prj = get_prj_file(barangay_shp)

            if barangay_prj:
                script += f"""
IMPORT FILENAME="{barangay_shp}"

COPY_ATTRS LAYER1_FILENAME="{road_shp}" \
    FROM_TYPE=AREAS \
    LAYER2_FILENAME="{barangay_shp}" \
    TO_TYPE=AREAS \
    {attrs_string} \
    MULTI_AREA=ALL \
    AREA_COVERAGE=PARTIAL
"""

                output_shp = f"{output_dir}/{os.path.basename(barangay_shp)}"
                output_prj = output_shp.replace(".shp", ".prj")

                script += f"""
EXPORT_VECTOR \
    FILENAME="{output_shp}" \
    EXPORT_LAYER="{barangay_shp}" \
    TYPE=SHAPEFILE
"""
                shutil.copy(barangay_prj, output_prj)
                output_files.append(output_shp)

        err, output, outputCount = gm.RunScript(script, 0x0, 0x0)

        if err != 0:
            messagebox.showerror("Error", f"Global Mapper script failed with error code: {err}")
            return

        # After export: add LOT_LOCATION and load into Global Mapper
        for output_shp in output_files:
            add_lot_location_field(output_shp)
            load_into_global_mapper(output_shp)

    except Exception as e:
        messagebox.showerror("Error", f"Processing failed:\n{e}")

def select_files_and_run(root):
    global road_shp, barangay_shps, output_files

    road_shp = filedialog.askopenfilename(
        title="Select Road Shapefile (LOT LOCATION)",
        filetypes=[("Shapefiles", "*.shp")],
        parent=root
    )
    if not road_shp:
        return

    try:
        gdf = gpd.read_file(road_shp)
        if "ROAD_ID" not in gdf.columns:
            gdf["ROAD_ID"] = range(len(gdf))
            gdf.to_file(road_shp)
    except Exception as e:
        messagebox.showerror("Error", f"Unable to update ROAD_ID field:\n{e}", parent=root)
        return

    barangay_shps = filedialog.askopenfilenames(
        title="Select Barangay Shapefiles (LOT LOCATION)",
        filetypes=[("Shapefiles", "*.shp")],
        parent=root
    )
    if not barangay_shps:
        return

    output_dir = filedialog.askdirectory(
        title="Select Output Directory (LOT LOCATION)",
        parent=root
    )
    if not output_dir:
        return
    output_dir = output_dir.replace("\\", "/")
    road_shp = road_shp.replace("\\", "/")

    process_lot_location(road_shp, barangay_shps, output_dir)

    messagebox.showinfo("Success", f"✅ Processing complete.\nSaved to:\n{output_dir}", parent=root)

def launch_gui():
    root = tk.Tk()
    root.withdraw()

    # 🔥 Set custom icon
    if os.path.exists(ICON_PATH):
        try:
            root.iconbitmap(ICON_PATH)
        except Exception as e:
            print(f"⚠ Failed to set custom icon: {e}")
    else:
        print(f"⚠ Icon file not found at: {ICON_PATH}")

    select_files_and_run(root)

if __name__ == "__main__":
    launch_gui()
