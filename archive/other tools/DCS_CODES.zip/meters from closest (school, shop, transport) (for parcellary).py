import os
import tkinter as tk
from tkinter import filedialog, messagebox
import geopandas as gpd
import osmnx as ox
import networkx as nx
from shapely.geometry import Point, LineString, box
from geopy.distance import geodesic
import pandas as pd
import subprocess

# 🔥 Set your paths here
ICON_PATH = r"D:/2025_PROJECTS/BLGF-GM_TEST/FOR TESTING/DCS_CODES/BLGF.ico"
GM_EXE_PATH = r"C:\Program Files\GlobalMapper26.1_64bit\global_mapper.exe"

ox.settings.use_cache = True
ox.settings.log_console = False

def load_into_global_mapper(shapefile_path):
    try:
        if not os.path.exists(GM_EXE_PATH):
            messagebox.showerror("Error", f"Global Mapper not found at:\n{GM_EXE_PATH}")
            return
        cmd = f'"{GM_EXE_PATH}" "{shapefile_path}"'
        subprocess.Popen(cmd, shell=True)
        print(f"🗺️  Sent to Global Mapper: {shapefile_path}")
    except Exception as e:
        messagebox.showerror("Error", f"Failed to load into Global Mapper:\n{e}")

def select_files_and_run(root):
    shp_paths = filedialog.askopenfilenames(
        title="Select Barangay Shapefiles (METERS FROM...)", 
        filetypes=[("Shapefiles", "*.shp")], 
        parent=root
    )
    if not shp_paths:
        return

    poi_path = filedialog.askopenfilename(
        title="Select POI Shapefile (METERS FROM...)", 
        filetypes=[("Shapefiles", "*.shp")], 
        parent=root
    )
    if not poi_path:
        return

    output_dir = filedialog.askdirectory(
        title="Select Output Directory (METERS FROM...)", 
        parent=root
    )
    if not output_dir:
        return

    try:
        gdf_list = [gpd.read_file(path) for path in shp_paths]
        gdf = gpd.GeoDataFrame(pd.concat(gdf_list, ignore_index=True), crs=gdf_list[0].crs)
        poi_gdf = gpd.read_file(poi_path)

        gdf = gdf.to_crs(epsg=4326)
        poi_gdf = poi_gdf.to_crs(epsg=4326)

        gdf["LAT_LONG"] = gdf.geometry.centroid.apply(lambda c: f"{c.y:.6f}, {c.x:.6f}")

        for typ in ["SCHOOL", "SHOP", "TRANSPORT"]:
            for i in range(1, 4):
                gdf[f"{typ}{i}"] = None

        minx, miny, maxx, maxy = gdf.total_bounds
        buffer_deg = 0.02
        bbox_poly = box(minx - buffer_deg, miny - buffer_deg, maxx + buffer_deg, maxy + buffer_deg)

        print("📦 Downloading road network...")
        try:
            G = ox.graph_from_polygon(bbox_poly, network_type='drive')
        except Exception as e:
            print("❌ OSM download failed:", e)
            return

        def add_virtual_node(G, point, node_id):
            try:
                u, v, key = ox.distance.nearest_edges(G, point[1], point[0])
                edge_data = G.get_edge_data(u, v)[key]
                line = edge_data.get('geometry', LineString([
                    (G.nodes[u]['x'], G.nodes[u]['y']),
                    (G.nodes[v]['x'], G.nodes[v]['y'])
                ]))
                proj_point = line.interpolate(line.project(Point(point[1], point[0])))
                coords = (proj_point.y, proj_point.x)
                G.add_node(node_id, x=coords[1], y=coords[0])
                d_u = geodesic((G.nodes[u]['y'], G.nodes[u]['x']), coords).meters
                d_v = geodesic((G.nodes[v]['y'], G.nodes[v]['x']), coords).meters
                G.add_edge(u, node_id, 0, length=d_u)
                G.add_edge(node_id, u, 0, length=d_u)
                G.add_edge(v, node_id, 0, length=d_v)
                G.add_edge(node_id, v, 0, length=d_v)
                return node_id
            except Exception as e:
                print(f"⚠️ Failed to add virtual node at {point}: {e}")
                return None

        types = ["school", "shop", "transport"]

        for idx, row in gdf.iterrows():
            centroid = row.geometry.centroid
            lat, lon = centroid.y, centroid.x

            for typ in types:
                subset = poi_gdf[poi_gdf["type"].str.lower() == typ]
                if subset.empty:
                    print(f"⚠️ No POIs found for type: {typ}")
                    continue

                subset = subset.copy()
                subset["DIST"] = subset.geometry.distance(centroid)
                nearest_pois = subset.nsmallest(3, "DIST")

                for i, (_, poi_row) in enumerate(nearest_pois.iterrows(), start=1):
                    field_name = f"{typ.upper()}{i}"
                    try:
                        start_node = add_virtual_node(G, (lat, lon), f"start_{idx}_{typ}_{i}")
                        end_node = add_virtual_node(G, (poi_row.geometry.y, poi_row.geometry.x), f"end_{idx}_{typ}_{i}")

                        if start_node and end_node and nx.has_path(G, start_node, end_node):
                            length, _ = nx.bidirectional_dijkstra(G, start_node, end_node, weight='length')
                            gdf.at[idx, field_name] = round(length, 2)
                            print(f"✅ {field_name} = {length:.2f} m")
                        else:
                            raise Exception("Routing failed")

                    except Exception as e:
                        fallback = geodesic((lat, lon), (poi_row.geometry.y, poi_row.geometry.x)).meters
                        gdf.at[idx, field_name] = round(fallback, 2)
                        print(f"⚠️ {field_name} fallback = {fallback:.2f} m ({e})")

                    for node in [f"start_{idx}_{typ}_{i}", f"end_{idx}_{typ}_{i}"]:
                        if node in G:
                            G.remove_node(node)

        output_path = os.path.join(output_dir, "barangays_with_poi_distances.shp")
        gdf.to_file(output_path)

        print(f"✅ Output saved to: {output_path}")
        load_into_global_mapper(output_path)

        messagebox.showinfo("Success", f"✅ Processing complete!\nSaved to:\n{output_path}", parent=root)

    except Exception as e:
        messagebox.showerror("Error", f"Processing failed:\n{e}", parent=root)

def launch_gui():
    root = tk.Tk()
    root.title("Meters From... Processor")
    if os.path.exists(ICON_PATH):
        try:
            root.iconbitmap(ICON_PATH)
        except Exception as e:
            print(f"⚠ Failed to set custom icon: {e}")
    else:
        print(f"⚠ Icon file not found at: {ICON_PATH}")
    root.withdraw()
    select_files_and_run(root)

if __name__ == "__main__":
    launch_gui()
