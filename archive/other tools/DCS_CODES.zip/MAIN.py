import tkinter as tk
from tkinter import filedialog, messagebox, Listbox
import subprocess
import os
import json
import psycopg2
from sqlalchemy import text
from PIL import Image, ImageTk, ImageDraw
from road_width import update_all_tables, get_sqlalchemy_engine
from road_frontage import update_all_frontage_tables

ROAD_WIDTH_SCRIPT = r"D:\\2025_PROJECTS\\BLGF-GM_TEST\\FOR TESTING\\DCS_CODES - testing\\road_width.py"
ROAD_FRONTAGE_SCRIPT = r"D:\\2025_PROJECTS\\BLGF-GM_TEST\\FOR TESTING\\DCS_CODES - testing\\road_frontage.py"
GM_EXE_PATH = r"C:\\Program Files\\GlobalMapper26.1_64bit\\global_mapper.exe"
LAST_EDITED_FILE = "last_edit_source.json"

def load_connection():
    with open("db_conn.json", "r") as f:
        return json.load(f)

def record_edit_source(source_name):
    with open(LAST_EDITED_FILE, "w") as f:
        json.dump({"source": source_name}, f)

def track_popup_close(popup, label):
    def on_close():
        popup_windows[label] -= 1
        if popup_windows[label] <= 0:
            popup_windows[label] = 0
            canvas, bg_id = canvas_refs[label]
            canvas.clicked = False
            canvas.itemconfig(bg_id, image="")
        popup.destroy()
    popup.protocol("WM_DELETE_WINDOW", on_close)

def on_button_click(label):
    if label == "ROAD WIDTH":
        record_edit_source("road_width")
        show_road_width_options()
    elif label == "ROAD FRONTAGE":
        record_edit_source("road_frontage")
        show_road_frontage_options()
    elif label == "LOT LOCATION":
        popup_windows[label] += 1
        subprocess.Popen(['python', 'lot_location.py'], shell=True)
    elif label == "LAND SHAPE":
        popup_windows[label] += 1
        subprocess.Popen(['python', 'land_shape.py'], shell=True)
    elif label == "METERS FROM (SCHOOL, SHOP, TRANSPORT)":
        popup_windows[label] += 1
        subprocess.Popen(['python', 'meters from closest (school, shop, transport).py'], shell=True)

def show_road_width_options():
    popup = tk.Toplevel(root)
    popup.title("ROAD WIDTH Options")
    popup.geometry("350x120")
    track_popup_close(popup, "ROAD WIDTH")
    frame = tk.Frame(popup)
    frame.pack(expand=True, pady=20)
    tk.Button(frame, text="Process DB files", width=20, command=start_postgis_flow).pack(side="left", padx=10)
    tk.Button(frame, text="Process Local files", width=20,
              command=lambda: subprocess.Popen(["python", ROAD_WIDTH_SCRIPT], shell=True)).pack(side="right", padx=10)

def show_road_frontage_options():
    popup = tk.Toplevel(root)
    popup.title("ROAD FRONTAGE Options")
    popup.geometry("350x120")
    track_popup_close(popup, "ROAD FRONTAGE")
    frame = tk.Frame(popup)
    frame.pack(expand=True, pady=20)
    tk.Button(frame, text="Process DB files", width=20, command=start_frontage_postgis_flow).pack(side="left", padx=10)
    tk.Button(frame, text="Process Local files", width=20,
              command=lambda: subprocess.Popen(["python", ROAD_FRONTAGE_SCRIPT], shell=True)).pack(side="right", padx=10)

def start_postgis_flow():
    conn_info = load_connection()
    with psycopg2.connect(**conn_info) as conn:
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT DISTINCT table_name 
                FROM information_schema.columns 
                WHERE column_name='geom' AND table_schema='public'
            """)
            tables = [row[0] for row in cursor.fetchall()]
    if not tables:
        messagebox.showwarning("No Tables Found", "No spatial tables with 'geom' column found.")
        return
    road_win = tk.Toplevel(root)
    road_win.title("Select Road Table")
    track_popup_close(road_win, "ROAD WIDTH")
    tk.Label(road_win, text="Select Road Table:").pack(pady=5)
    road_list = Listbox(road_win, height=10)
    for t in tables:
        road_list.insert(tk.END, t)
    road_list.pack(padx=10, pady=5)
    def on_road_selected():
        selected_road = road_list.get(road_list.curselection())
        road_win.destroy()
        select_barangay_tables(selected_road, tables, script=ROAD_WIDTH_SCRIPT, label="ROAD WIDTH")
    tk.Button(road_win, text="OK", command=on_road_selected).pack(pady=10)

def start_frontage_postgis_flow():
    conn_info = load_connection()
    with psycopg2.connect(**conn_info) as conn:
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT DISTINCT table_name 
                FROM information_schema.columns 
                WHERE column_name='geom' AND table_schema='public'
            """)
            tables = [row[0] for row in cursor.fetchall()]
    if not tables:
        messagebox.showwarning("No Tables Found", "No spatial tables with 'geom' column found.")
        return
    road_win = tk.Toplevel(root)
    road_win.title("Select Road Table")
    track_popup_close(road_win, "ROAD FRONTAGE")
    tk.Label(road_win, text="Select Road Table:").pack(pady=5)
    road_list = Listbox(road_win, height=10)
    for t in tables:
        road_list.insert(tk.END, t)
    road_list.pack(padx=10, pady=5)
    def on_road_selected():
        selected_road = road_list.get(road_list.curselection())
        road_win.destroy()
        select_barangay_tables(selected_road, tables, script=ROAD_FRONTAGE_SCRIPT, label="ROAD FRONTAGE")
    tk.Button(road_win, text="OK", command=on_road_selected).pack(pady=10)

def select_barangay_tables(road_table, tables, script, label):
    brgy_win = tk.Toplevel(root)
    brgy_win.title("Select Barangay Tables")
    track_popup_close(brgy_win, label)
    tk.Label(brgy_win, text="Select Barangay Tables:").pack(pady=5)
    brgy_list = Listbox(brgy_win, selectmode=tk.MULTIPLE, height=12)
    for t in tables:
        brgy_list.insert(tk.END, t)
    brgy_list.pack(padx=10, pady=5)
    def on_brgy_selected():
        selected_brgy = [brgy_list.get(i) for i in brgy_list.curselection()]
        if not selected_brgy:
            messagebox.showwarning("Select Barangays", "Please select at least one barangay table.")
            return
        brgy_win.destroy()
        ask_output_directory(road_table, selected_brgy, script)
    tk.Button(brgy_win, text="OK", command=on_brgy_selected).pack(pady=10)

def ask_output_directory(road_table, brgy_tables, script):
    output_dir = filedialog.askdirectory(title="Select Output Folder")
    if not output_dir:
        return
    args = ["python", script, "--from-db", "--road", road_table, "--brgy", ",".join(brgy_tables), "--output", output_dir]
    subprocess.Popen(args, shell=True)

def update_database_function():
    try:
        if os.path.exists(LAST_EDITED_FILE):
            with open(LAST_EDITED_FILE, "r") as f:
                source = json.load(f).get("source", "")
            if source == "road_frontage":
                update_all_frontage_tables()
            else:
                update_all_tables()
        else:
            update_all_tables()
        messagebox.showinfo("Update DB", "✅ Processed data successfully updated in PostgreSQL.")
    except Exception as e:
        messagebox.showerror("Update DB Error", f"❌ Failed to update DB:\n{e}")

root = tk.Tk()
root.title("Data Collection Sheet")
root.geometry("320x140")
icon_path = "D:/2025_PROJECTS/BLGF-GM_TEST/FOR TESTING/DCS_CODES/BLGF.ico"
if os.path.exists(icon_path):
    root.iconbitmap(icon_path)

# === IMAGE HANDLING ===
def round_image(img_path, size=(38, 38), radius=7):
    img = Image.open(img_path).convert("RGBA")

    # Resize while maintaining aspect ratio and center it on a square canvas
    original_ratio = img.width / img.height
    target_w, target_h = size

    if img.width != img.height:
        # Create square background
        max_dim = max(img.width, img.height)
        square_img = Image.new("RGBA", (max_dim, max_dim), (0, 0, 0, 0))
        paste_x = (max_dim - img.width) // 2
        paste_y = (max_dim - img.height) // 2
        square_img.paste(img, (paste_x, paste_y))
        img = square_img

    img = img.resize(size, Image.Resampling.LANCZOS)

    # Apply rounded mask
    mask = Image.new("L", size, 0)
    draw = ImageDraw.Draw(mask)
    draw.rounded_rectangle((0, 0, size[0], size[1]), radius=radius, fill=255)

    img.putalpha(mask)
    return ImageTk.PhotoImage(img)


hover_bg = round_image(
    r"D:\2025_PROJECTS\BLGF-GM_TEST\FOR TESTING\DCS_CODES - testing\icons\hover.png",
    size=(38, 38),
    radius=7
)

clicked_bg = round_image(
    r"D:\2025_PROJECTS\BLGF-GM_TEST\FOR TESTING\DCS_CODES - testing\icons\click.png",
    size=(38, 38),
    radius=7
)


icon_paths = {
    "ROAD WIDTH": r"D:\\2025_PROJECTS\\BLGF-GM_TEST\\FOR TESTING\\DCS_CODES - testing\\icons\\roadwidth.png",
    "ROAD FRONTAGE": r"D:\\2025_PROJECTS\\BLGF-GM_TEST\\FOR TESTING\\DCS_CODES - testing\\icons\\roadfrontage.png",
    "LOT LOCATION": r"D:\\2025_PROJECTS\\BLGF-GM_TEST\\FOR TESTING\\DCS_CODES - testing\\icons\\lotlocation.png",
    "LAND SHAPE": r"D:\\2025_PROJECTS\\BLGF-GM_TEST\\FOR TESTING\\DCS_CODES - testing\\icons\\landshape.png",
    "METERS FROM (SCHOOL, SHOP, TRANSPORT)": r"D:\\2025_PROJECTS\\BLGF-GM_TEST\\FOR TESTING\\DCS_CODES - testing\\icons\\distancefrom.png"
}

icons = {
    label: ImageTk.PhotoImage(Image.open(path).resize((39, 39), Image.Resampling.LANCZOS))
    for label, path in icon_paths.items()
}

# === TOOLTIP CLASS ===
class ToolTip:
    def __init__(self, widget, text, icon_image):
        self.widget = widget
        self.text = text
        self.icon_image = icon_image
        self.tipwindow = None

    def show(self, event=None):
        if self.tipwindow or not self.text:
            return
        x = self.widget.winfo_pointerx() + 10
        y = self.widget.winfo_pointery() + 10

        self.tipwindow = tw = tk.Toplevel(self.widget)
        tw.wm_overrideredirect(True)
        tw.wm_geometry(f"+{x}+{y}")

        frame = tk.Frame(tw, bg="#ffffe0", bd=1, relief="solid")
        frame.pack()

        tk.Label(frame, image=self.icon_image, bg="#ffffe0").pack(side="left", padx=5, pady=3)
        tk.Label(frame, text=self.text, bg="#ffffe0", font=("tahoma", 9, "bold")).pack(side="left", padx=5, pady=3)

    def hide(self, event=None):
        if self.tipwindow:
            self.tipwindow.destroy()
            self.tipwindow = None




# === TOOLBAR BUTTONS ===
button_frame = tk.Frame(root, bg="#afd0f7", width=300, height=50)# Set exact width/height
button_frame.pack(padx=3, pady=15)
button_frame.pack_propagate(False)  # Prevent auto-resize to children

buttons = [
    "ROAD WIDTH",
    "ROAD FRONTAGE",
    "LOT LOCATION",
    "LAND SHAPE",
    "METERS FROM (SCHOOL, SHOP, TRANSPORT)"
]

tooltip_texts = {
    "ROAD WIDTH": "Road Width",
    "ROAD FRONTAGE": "Road Frontage",
    "LOT LOCATION": "Lot Location",
    "LAND SHAPE": "Land Shape",
    "METERS FROM (SCHOOL, SHOP, TRANSPORT)": "Distance from School/Shop/Transport"
}

popup_windows = {}
canvas_refs = {}

for label in buttons:
    canvas = tk.Canvas(button_frame, width=48, height=48, highlightthickness=0, bg="#afd0f7")
    bg_img_id = canvas.create_image(3, 3, anchor="nw", image=None)
    icon_img_id = canvas.create_image(2, 2, anchor="nw", image=icons[label])
    tooltip = ToolTip(canvas, tooltip_texts[label], icons[label])
    canvas.tag_bind(icon_img_id, "<Enter>", tooltip.show)
    canvas.tag_bind(icon_img_id, "<Leave>", tooltip.hide)


    canvas_refs[label] = (canvas, bg_img_id)
    popup_windows[label] = 0

    def make_bindings(c, lbl, bg_id):
        def on_enter(e):
            c.itemconfig(bg_id, image=hover_bg)

        def on_leave(e):
            if popup_windows[lbl] > 0 or c.clicked:
                c.itemconfig(bg_id, image=clicked_bg)
            else:
                c.itemconfig(bg_id, image="")

        def on_click(e):
            c.itemconfig(bg_id, image=clicked_bg)
            c.clicked = True
            popup_windows[lbl] += 1
            on_button_click(lbl)

        c.clicked = False
        c.bind("<Enter>", on_enter)
        c.bind("<Leave>", on_leave)
        c.bind("<Button-1>", on_click)

    make_bindings(canvas, label, bg_img_id)
    if label == "ROAD WIDTH":
        canvas.pack(side="left", padx=(0, 0), pady=5)
    elif label == "ROAD FRONTAGE":
        canvas.pack(side="left", padx=(0, 0), pady=5)
    elif label == "LOT LOCATION":
        canvas.pack(side="left", padx=1, pady=5)
    elif label == "LAND SHAPE":
        canvas.pack(side="left", padx=1, pady=5)
    elif label == "METERS FROM (SCHOOL, SHOP, TRANSPORT)":
        canvas.pack(side="left", padx=(1, 6), pady=5)




# === UPDATE DB BUTTON ===
update_btn = tk.Button(
    root, text="Update DB",
    width=40,
    command=update_database_function,
    bg="#007acc",
    fg="white",
    activebackground="#005f99",
    activeforeground="white",
    relief="flat"
)
update_btn.pack(pady=10)

root.mainloop()
