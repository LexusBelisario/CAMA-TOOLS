import tkinter as tk
from tkinter import filedialog, messagebox
import geopandas as gpd
from shapely.geometry import Point, LineString
from shapely.ops import nearest_points
from scipy.spatial import cKDTree
import os
import subprocess
import argparse
import json
import psycopg2
from sqlalchemy import create_engine, text

ICON_PATH = "D:/2025_PROJECTS/BLGF-GM_TEST/FOR TESTING/DCS_CODES/BLGF.ico"
GM_EXE_PATH = r"C:\\Program Files\\GlobalMapper26.1_64bit\\global_mapper.exe"
LAST_OUTPUT_TXT = "D:/2025_PROJECTS/BLGF-GM_TEST/FOR TESTING/DCS_CODES/last_output_path.txt"
PROCESSED_OUTPUTS_JSON = "processed_outputs.json"

processed_outputs = {}  # Shared between scripts


def set_processed_outputs(table_list, output_dir):
    global processed_outputs
    processed_outputs = {
        table: os.path.join(output_dir, f"{table}_with_road_width.shp") for table in table_list
    }
    with open(PROCESSED_OUTPUTS_JSON, "w") as f:
        json.dump(processed_outputs, f)


def open_in_global_mapper(filepath):
    if os.path.exists(GM_EXE_PATH) and os.path.exists(filepath):
        subprocess.Popen([GM_EXE_PATH, filepath], shell=True)


def get_sqlalchemy_engine():
    with open("db_conn.json", "r") as f:
        config = json.load(f)
    uri = f"postgresql+psycopg2://{config['user']}:{config['password']}@{config['host']}:{config['port']}/{config['dbname']}"
    return create_engine(uri)


def load_from_postgis(table):
    engine = get_sqlalchemy_engine()
    with engine.connect() as conn:
        result = conn.execute(text(f"""
            SELECT column_name FROM information_schema.columns
            WHERE table_name = '{table}' AND udt_name = 'geometry'
        """))
        geom_cols = [row[0] for row in result]
    if not geom_cols:
        raise ValueError(f"No geometry column found in table: {table}")
    if len(geom_cols) > 1:
        raise ValueError(f"Multiple geometry columns found: {geom_cols}")
    geom_col = geom_cols[0]

    query = f'SELECT * FROM "{table}"'
    gdf = gpd.read_postgis(sql=query, con=engine, geom_col=geom_col)
    if not gdf.crs:
        gdf.set_crs("EPSG:32651", inplace=True)
    return gdf


def update_db_from_output(shapefile_path, target_table):
    engine = get_sqlalchemy_engine()
    gdf = gpd.read_file(shapefile_path)
    if not gdf.crs:
        gdf.set_crs("EPSG:32651", inplace=True)

    if 'geometry' in gdf.columns:
        gdf = gdf.rename(columns={'geometry': 'geom'})
        gdf.set_geometry('geom', inplace=True)

    gdf.to_postgis(name=target_table, con=engine, if_exists='replace', index=False)
    print(f"✅ Updated table '{target_table}' in PostgreSQL from {shapefile_path}")


def update_all_tables():
    try:
        if not os.path.exists(PROCESSED_OUTPUTS_JSON):
            raise FileNotFoundError("processed_outputs.json not found.")

        with open(PROCESSED_OUTPUTS_JSON, "r") as f:
            saved_outputs = json.load(f)

        for table, path in saved_outputs.items():
            try:
                update_db_from_output(path, table)
            except Exception as e:
                print(f"❌ Failed to update {table}: {e}")
    except Exception as e:
        print("❌ Could not perform update_all_tables:", e)


def process(barangay_gdf, road_gdf):
    if not barangay_gdf.crs or not road_gdf.crs:
        raise ValueError("Missing CRS.")
    if barangay_gdf.crs != road_gdf.crs:
        road_gdf = road_gdf.to_crs(barangay_gdf.crs)

    segment_geoms = []
    segment_midpoints = []

    for idx, geom in enumerate(road_gdf.geometry):
        if geom is None or geom.is_empty:
            print(f"⚠️ Skipping empty geometry at index {idx}")
            continue
        try:
            parts = geom.geoms if geom.geom_type in ['MultiLineString', 'GeometryCollection'] else [geom]
            for ls in parts:
                if ls.geom_type != "LineString":
                    print(f"⚠️ Skipping non-LineString part at index {idx}: {ls.geom_type}")
                    continue
                coords = list(ls.coords)
                for i in range(len(coords) - 1):
                    seg = LineString([coords[i], coords[i + 1]])
                    segment_geoms.append(seg)
                    midpoint = seg.interpolate(0.5, normalized=True)
                    segment_midpoints.append((midpoint.x, midpoint.y))
        except Exception as e:
            print(f"❌ Error parsing geometry at index {idx}: {e}")
            continue

    if not segment_midpoints:
        raise ValueError("No valid road segments found to build KDTree. Your road data may be malformed or missing.")

    tree = cKDTree(segment_midpoints)
    road_widths = []

    for idx in range(len(barangay_gdf)):
        poly = barangay_gdf.geometry.iloc[idx]
        boundary = poly.boundary
        all_coords = []
        if boundary.geom_type == 'MultiLineString':
            for geom in boundary.geoms:
                all_coords.extend(geom.coords)
        else:
            all_coords = list(boundary.coords)

        boundary_points = [Point(c) for c in all_coords]
        coords_list = [(p.x, p.y) for p in boundary_points]
        dists, indices = tree.query(coords_list)
        min_idx = dists.argmin()
        nearest_index = indices[min_idx]
        nearest_segment = segment_geoms[nearest_index]
        closest_point = boundary_points[min_idx]

        nearest_on_road = nearest_segment.interpolate(nearest_segment.project(closest_point))
        nearest_on_feature = nearest_points(nearest_on_road, boundary)[1]
        width = nearest_on_road.distance(nearest_on_feature) * 2
        road_widths.append(width)

    barangay_gdf["ROAD_WIDTH"] = road_widths
    return barangay_gdf



def save_and_open(barangay_gdf, name, output_dir):
    output_path = os.path.join(output_dir, f"{name}_with_road_width.shp")
    barangay_gdf.to_file(output_path)
    with open(LAST_OUTPUT_TXT, "w") as f:
        f.write(output_path)
    processed_outputs[name] = output_path
    with open(PROCESSED_OUTPUTS_JSON, "w") as f:
        json.dump(processed_outputs, f)
    open_in_global_mapper(output_path)


def run_local_gui():
    root = tk.Tk()
    root.withdraw()

    road_path = filedialog.askopenfilename(title="Select Road Shapefile", filetypes=[("Shapefiles", "*.shp")])
    if not road_path:
        return
    brgy_paths = filedialog.askopenfilenames(title="Select Barangay Shapefiles", filetypes=[("Shapefiles", "*.shp")])
    if not brgy_paths:
        return
    output_dir = filedialog.askdirectory(title="Select Output Folder")
    if not output_dir:
        return

    road_gdf = gpd.read_file(road_path)
    for brgy_path in brgy_paths:
        brgy_gdf = gpd.read_file(brgy_path)
        result = process(brgy_gdf, road_gdf)
        name = os.path.splitext(os.path.basename(brgy_path))[0]
        save_and_open(result, name, output_dir)


def run_from_postgis(road_table, brgy_tables, output_dir):
    road_gdf = load_from_postgis(road_table)
    for brgy_table in brgy_tables:
        brgy_gdf = load_from_postgis(brgy_table)
        result = process(brgy_gdf, road_gdf)
        save_and_open(result, brgy_table, output_dir)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--from-db", action="store_true")
    parser.add_argument("--road", type=str)
    parser.add_argument("--brgy", type=str)
    parser.add_argument("--output", type=str)
    args = parser.parse_args()

    if args.from_db:
        brgy_list = args.brgy.split(",")
        run_from_postgis(args.road, brgy_list, args.output)
        set_processed_outputs(brgy_list, args.output)
    else:
        run_local_gui()
